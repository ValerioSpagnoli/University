#include <stdio.h>
int check(int* dest, int *src, int n, int m) {
	int i;
	for (i=0; i<n; i++) {
		if (dest[i] != src[m-1-i%m]) {
            return 1;
        }
    }
	return 0;
}
