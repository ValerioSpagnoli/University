int mcopy(int *dest, int *src, int n, int m) {
	if (n%m) return -1; // n deve essere multiplo di m
	int i;
	for (i=0; i<n; i++)
		dest[i] = src[m-1-i%m];
	return 0;
}
