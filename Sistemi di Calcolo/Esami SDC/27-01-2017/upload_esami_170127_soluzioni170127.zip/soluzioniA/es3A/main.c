#include <stdio.h>
#include <stdlib.h>

// parametri di configurazione
#define M		8
#define N		10000000*M
#define ITER	10

// funzioni definite in mcopy.c e check.o
int mcopy(int *dest, int *src, int n, int m);
int check(int* dest, int *src, int n, int m);

int main() {
	int i;
	int src[M];
	int *dest = calloc(N, sizeof(int));

	for (i=0; i<M; i++) src[i] = i;

	for (i=0; i<ITER; i++) mcopy(dest, src, N, M);

    int status = check(dest, src, N, M); // 1 se check fallisce
	if (status) {
		printf("ERRORE: dati prodotti non conformi a quanto atteso!\n");
	}

    free(dest);
	return status;
}
