#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define START	86028157

volatile int shouldStop = 0;

void writeToFile(int fd, char* buf, int len) {
	// per semplicità non gestiamo interruzioni e scritture parziali
	if (write(fd, buf, len) == -1) {
		perror("write fallita");
		exit(1);
	}
}

int prime(unsigned int n) { // solo per n>=3 dispari
	unsigned int i;
	for (i=3; i<n/2; i+=2)
		if (n%i==0) return 0;
	return 1;
}

void handler(int signo, siginfo_t *siginfo, void *context) {
	char* s = (signo == SIGINT) ? "SIGINT" : "SIGTERM";
	printf("Segnale %s ricevuto: imposto shouldStop = 1\n", s);
	shouldStop = 1;
}

int main() {
	// registrazione signal handler (comune per i due segnali)
    struct sigaction act;
    memset(&act, 0, sizeof(struct sigaction));

    act.sa_flags = SA_SIGINFO;
    act.sa_sigaction = handler;

    if (sigaction(SIGINT, &act, NULL)) {
        perror("sigaction fallita");
        exit(1);
    }
    if (sigaction(SIGTERM, &act, NULL)) {
        perror("sigaction fallita");
        exit(1);
    }
	
	// apertura descrittore
	int fd = open("out.txt", O_WRONLY|O_CREAT|O_TRUNC, 0644);
	if (fd == -1) {
		perror("open fallita");
		exit(1);
	}

	// main loop per generazione numeri e stringhe da salvare in out.txt
	char buf[11];
	unsigned int num = START, found = 0;
	while (!shouldStop) {
		if (prime(num)) {
			int ret = sprintf(buf, "%u", num);
			buf[ret++] = '\n';
			writeToFile(fd, buf, ret);
			++found;
		}
		num += 2;
	}
	
	printf("Numeri primi trovati partendo da %u: %u\n", START, found);
	
	// chiusura descrittore
	if (close(fd) == -1) {
		perror("close fallita");
		exit(1);
	}
	
	return 0;
}