#ifndef __COL2ROW__
#define __COL2ROW__

void col2row(int** a, int n, int i, int j);

#endif
