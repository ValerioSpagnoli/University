int media(int, int);

int test(const int* a, const int* b, const int* c) {
    return media(*a,*b) + media(*b,*c) > *a;
}
