#include <stdio.h>

int test(const int*, const int*, const int*);

int main() {
    int x, y, z, res;
    x=10, y=20, z=30, res = test(&x, &y, &z);
    printf("%d (corretto=1)\n", res);
    x=30, y=20, z=10, res = test(&x, &y, &z);
    printf("%d (corretto=1)\n", res);
    x=-10, y=-20, z=-30, res = test(&x, &y, &z);
    printf("%d (corretto=0)\n", res);
    x=-30, y=-20, z=-10, res = test(&x, &y, &z);
    printf("%d (corretto=0)\n", res);
    return 0;
}
