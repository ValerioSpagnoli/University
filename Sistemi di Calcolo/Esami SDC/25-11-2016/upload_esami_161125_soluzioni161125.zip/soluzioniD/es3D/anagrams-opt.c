#include "anagrams.h"

#if 0

// soluzione 1 con inlining e cortocircuitazione

static char _lower(char c) {
    if (c >= 'A' && c <= 'Z') return c - 'A' + 'a';
    return c;
}

int count(char c, const char* s) {
    int cnt = 0;
    while (*s) cnt += _lower(c) == _lower(*s++);
    return cnt;
}

int anagrams(const char* a, const char* b) {
    const char* p = a;
    while (*p) {
        if (count(*p, a) != count(*p, b)) return 0;
        p++;
    }
    return 1;
}
#else

// soluzione 2 con cambio completo dell'algoritmo

#include <string.h>
int anagrams(const char* a, const char* b) {
    char ma[256] = { 0 };
    char mb[256] = { 0 };
    while (*a) ma[*a++]++;
    while (*b) mb[*b++]++;
    return !memcmp(ma,mb,256);
}

#endif
