#include "anagrams.h"

int count(char c, const char* s) {
    int cnt = 0;
    while (*s) cnt += c == lower(*s++);
    return cnt;
}

int anagrams(const char* a, const char* b) {
    int cnt = 0;
    const char* p = a;
    while (*p) {
        cnt += count(lower(*p), a) !=
               count(lower(*p), b);
        p++;
    }
    return cnt == 0;
}
