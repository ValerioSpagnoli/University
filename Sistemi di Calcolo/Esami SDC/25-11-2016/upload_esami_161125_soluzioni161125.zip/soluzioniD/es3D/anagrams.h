#ifndef __ANAGRAMS__
#define __ANAGRAMS__

char lower(char c);
int anagrams(const char* a, const char* b);

#endif
