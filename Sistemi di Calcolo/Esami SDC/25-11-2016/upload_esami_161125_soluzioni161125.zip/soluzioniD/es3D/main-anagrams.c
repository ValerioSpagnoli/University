#include <stdio.h>
#include "anagrams.h"

#define N 1000000

char lower(char c) {
    if (c >= 'A' && c <= 'Z') return c - 'A' + 'a';
    return c;
}

int main() {
    int i, c = 0;

    for (i=0; i<N; i++) {
        c += anagrams("algoritmo", "logaritmo");
        c += anagrams("trancio", "cartoni");
        c += anagrams("sfrenati", "finestra");
        c += anagrams("minestra", "finestra");
        c += anagrams("precipitazioni", "pioggia");
    }

    printf("%d (corretto=%d)\n", c, 3*N);
    printf("%d (corretto=1)\n", anagrams("algoritmo", "logaritmo"));
    printf("%d (corretto=1)\n", anagrams("trancio", "cartoni"));
    printf("%d (corretto=1)\n", anagrams("sfrenati", "finestra"));
    printf("%d (corretto=0)\n", anagrams("minestra", "finestra"));
    printf("%d (corretto=0)\n", anagrams("precipitazioni", "pioggia"));

    return 0;
}
