void arrayProdWithDeref(int** x, int** y, int* z, int n) {
    int** end = x+n;

    while (x < end) {
        if (**x && **y)
            *z = (**x) * (**y);
        else
            *z = 0;
        x++, y++, z++;
    }
}
