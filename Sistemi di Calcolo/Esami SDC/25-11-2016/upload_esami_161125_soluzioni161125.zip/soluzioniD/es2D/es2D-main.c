#include <stdio.h>

void arrayProdWithDeref(int** x, int** y, int* z, int n);

void printArrayDeref(int **v, int n) {
    printf("{");
    int i = 0;
    for (i=0; i<n-1; ++i)
        printf("%u, ", *v[i]);
    printf("%u", *v[i]);
    printf("}");
}

void printArray(int *v, int n) {
    printf("{");
    int i = 0;
    for (i=0; i<n-1; ++i)
        printf("%u, ", v[i]);
    printf("%u", v[i]);
    printf("}");
}

int main() {
    int i;
    int *p;
    int z[5];

    int T1[] = {1, 2, 0, 4, 2, 0, 3, 5};
    int *x1[4], *y1[4];

    p = T1;
    for (i=0; i<4; i++) x1[i] = p++;
    for (i=0; i<4; i++) y1[i] = p++;

    printf("Test 1:\nx: ");
    printArrayDeref(x1, 4);
    printf("\ny: ");
    printArrayDeref(y1, 4);
    arrayProdWithDeref(x1, y1, z, 4);
    printf("\nz: ");
    printArray(z, 4);
    printf("\nRisultato atteso:\nz: {2, 0, 0, 20}\n");

    int T2[] = {0, 7, 1, 0, 3, 2, 0, 1, 2, 1};
    int *x2[5], *y2[5];

    p = T2;
    for (i=0; i<5; i++) x2[i] = p++;
    for (i=0; i<5; i++) y2[i] = p++;

    printf("\nTest 2:\nx: ");
    printArrayDeref(x2, 5);
    printf("\ny: ");
    printArrayDeref(y2, 5);
    arrayProdWithDeref(x2, y2, z, 5);
    printf("\nz: ");
    printArray(z, 5);
    printf("\nRisultato atteso:\nz: {0, 0, 1, 0, 3}\n");

    return 0;
}
