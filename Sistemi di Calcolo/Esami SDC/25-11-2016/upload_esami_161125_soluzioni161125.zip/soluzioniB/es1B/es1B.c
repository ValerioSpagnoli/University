int media(int, int);

int test(const char* x, const char* y) {
    return media(*x,*y) <= *x || *y <= media(*x,*y);
}
