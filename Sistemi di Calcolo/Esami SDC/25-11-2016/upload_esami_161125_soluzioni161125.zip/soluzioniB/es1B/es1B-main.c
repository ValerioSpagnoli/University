#include <stdio.h>

int test(const char* x, const char* y);

int main() {
    char x, y;
    int res;
    x=10, y=20, res=test(&x, &y);
    printf("test(&x,&y)=%d (corretto=0)\n", res);
    x=10, y=10, res=test(&x, &y);
    printf("test(&x,&y)=%d (corretto=1)\n", res);
    x=-10, y=-20, res=test(&x, &y);
    printf("test(&x,&y)=%d (corretto=1)\n", res);
    x=-20, y=-10, res=test(&x, &y);
    printf("test(&x,&y)=%d (corretto=0)\n", res);
    return 0;
}
