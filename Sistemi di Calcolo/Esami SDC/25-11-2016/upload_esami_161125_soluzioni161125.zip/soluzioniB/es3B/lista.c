#include <stdlib.h>
#include "lista.h"

typedef struct nodo nodo;

struct nodo { // nodo lista
    int   elem;
    nodo* next;
};

struct lista {
    nodo* first; // lrimo nodo della lista
};

lista* lista_new(){ // crea lista vuota
    return calloc(1, sizeof(lista));
}

void lista_addLast(lista* l, int x){ // aggiunge in coda
    nodo* last = l->first;
    if (last != NULL)
        while (last->next != NULL) last = last->next;
    nodo* n = malloc(sizeof(nodo));
    n->elem = x;
    n->next = NULL;
    if (l->first == NULL) l->first = n;
    else last->next = n;
}

int lista_removeFirst(lista* l, int* x){ // rimuove dalla testa
    if (l->first == NULL) return -1;
    nodo* dead = l->first;
    if (x != NULL) *x = dead->elem;
    l->first = dead->next;
    free(dead);
    return 0;
}

void lista_del(lista* l){ // dealloca lista
    while (l->first != NULL) lista_removeFirst(l, NULL);
    free(l);
}
