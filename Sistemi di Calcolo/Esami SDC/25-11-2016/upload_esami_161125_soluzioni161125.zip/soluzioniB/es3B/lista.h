#ifndef __LISTA__
#define __LISTA__

typedef struct lista lista;

lista* lista_new();
void   lista_addLast(lista*, int);
int    lista_removeFirst(lista*, int*);
void   lista_del(lista*);

#endif
