#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

#define N 35000

int main() {

    int i;
    lista* p = lista_new();

    for (i=0; i<N; i++) lista_addLast(p, i);

    for (i=0; i<N; i++) {
        int x, res = lista_removeFirst(p, &x);
        if (res == -1 || x != i)
            exit((printf("Errore lista_removeFirst\n"),1));
    }

    for (i=0; i<N; i++) lista_addLast(p, i);

    lista_del(p);

    printf("Apparentemente ok, usare valgrind per verifica più approfondita\n");
    return 0;
}
