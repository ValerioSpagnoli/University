void concatReverse(char* s1, char* s2, char* dest, int len_s1, int len_s2) {
    while (*s1) *dest++ = *s1++;

    int i = 0;
    for (; i < len_s2; i++) *dest++ = s2[len_s2-i-1];

    *dest = 0;
}
