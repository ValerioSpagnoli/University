#include <stdio.h>
#include <string.h>

void concatReverse(char* s1, char* s2, char* dest, int len_s1, int len_s2);

int main() {
    char *s1 = "juventus";
    char *s2 = "roma";
    char *s3 = "";

    int len_s1 = strlen(s1);
    int len_s2 = strlen(s2);

    char dest[14];

    concatReverse(s1, s2, dest, len_s1, len_s2);
    printf("\"%s\" \"%s\" -> \"%s\" (atteso: \"juventusamor\")\n", s1, s2, dest);

    concatReverse(s2, s1, dest, len_s2, len_s1);
    printf("\"%s\" \"%s\" -> \"%s\" (atteso: \"romasutnevuj\")\n", s2, s1, dest);

    concatReverse(s1, s3, dest, len_s1, 0);
    printf("\"%s\" \"\" -> \"%s\" (atteso: \"juventus\")\n", s1, dest);

    concatReverse(s3, s2, dest, 0, len_s2);
    printf("\"\" \"%s\" -> \"%s\" (atteso: \"amor\")\n", s2, dest);

    return 0;
}
