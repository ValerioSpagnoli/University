#include <stdlib.h>
#include "pila.h"

typedef struct nodo nodo;

struct nodo { // nodo lista
    int   elem;
    nodo* next;
};

struct pila {
    nodo* top; // nodo top della lista
    int len;   // lunghezza della lista
};

pila* pila_new(){ // crea pila vuota
    return calloc(1, sizeof(pila));
}

int pila_len(const pila* p){ // lunghezza
    return p->len;
}

void pila_push(pila* p, int x){ // push in cima
    nodo* n = malloc(sizeof(nodo));
    n->elem = x;
    n->next = p->top;
    p->top  = n;
    p->len++;
}

int pila_pop(pila* p, int* x){ // pop dalla cima
    if (pila_len(p) == 0) return -1;
    nodo* dead = p->top;
    if (x != NULL) *x = dead->elem;
    p->top = dead->next;
    free(dead);
    p->len--;
    return 0;
}

void pila_del(pila* p){ // dealloca pila
    while (p->top != NULL) pila_pop(p, NULL);
    free(p);
}
