#include <stdio.h>
#include <stdlib.h>
#include "pila.h"

#define N 35000

int main() {

    int i;
    pila* p = pila_new();

    for (i=0; i<N; i++) {
        if (pila_len(p) != i)
            exit((printf("Errore pila_len\n"),1));
        pila_push(p, i);
    }

    for (i=0; i<N; i++) {
        int x, res = pila_pop(p, &x);
        if (res == -1 || x != N-1-i)
            exit((printf("Errore pila_pop\n"),1));
    }

    for (i=0; i<N; i++) pila_push(p, i);

    pila_del(p);
    printf("Apparentemente ok, usare valgrind per verifica più approfondita\n");
    return 0;
}
