#ifndef __PILA__
#define __PILA__

typedef struct pila pila;

pila* pila_new();
int   pila_len(const pila*);
void  pila_push(pila*, int);
int   pila_pop(pila*, int*);
void  pila_del(pila*);

#endif
