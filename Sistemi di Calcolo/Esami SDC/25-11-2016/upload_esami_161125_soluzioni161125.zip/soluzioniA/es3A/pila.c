#include <stdlib.h>
#include "pila.h"

typedef struct nodo nodo;

struct nodo { // nodo lista
    int   elem;
    nodo* next;
};

struct pila {
    nodo* top; // nodo top della lista
};

pila* pila_new(){ // crea pila vuota
    return calloc(1, sizeof(pila));
}

int pila_len(const pila* p){ // lunghezza
    nodo* n;
    int c = 0;
    for (n = p->top; n != NULL; n = n->next) c++;
    return c;
}

void pila_push(pila* p, int x){ // push in cima
    nodo* n = malloc(sizeof(nodo));
    n->elem = x;
    n->next = p->top;
    p->top  = n;
}

int pila_pop(pila* p, int* x){ // pop dalla cima
    if (pila_len(p) == 0) return -1;
    nodo* dead = p->top;
    if (x != NULL) *x = dead->elem;
    p->top = dead->next;
    free(dead);
    return 0;
}

void pila_del(pila* p){ // dealloca pila
    while (p->top != NULL) pila_pop(p, NULL);
    free(p);
}
