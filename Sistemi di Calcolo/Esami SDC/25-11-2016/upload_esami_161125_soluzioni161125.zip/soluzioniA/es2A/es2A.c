void concatReverse(char* s1, char* s2, char* dest, int len_s1, int len_s2) {
    int i = 0;
    s1 = s1 + len_s1 - 1;
    for (; i < len_s1; i++) dest[i] = *s1--;
    while (*s2) dest[i++] = *s2++;
    dest[i] = 0;
}
