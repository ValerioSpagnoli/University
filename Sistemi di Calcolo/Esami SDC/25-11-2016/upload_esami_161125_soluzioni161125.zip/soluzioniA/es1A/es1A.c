int media(int, int);

int test(const short* x, const short* y) {
    return *x < media(*x,*y) && media(*x,*y) < *y;
}
