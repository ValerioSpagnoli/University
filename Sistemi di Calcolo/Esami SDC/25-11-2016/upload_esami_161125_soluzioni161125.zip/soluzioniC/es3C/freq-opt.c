#include <string.h>
#include "freq.h"

static int prefix(const char* a, const char* b) {
    while (*a && *b) if (*a++ != *b++) return 0;
    return !*a;
}

static int substring(const char* sub, const char* text) {
    int i, c = 0, n = strlen(text)-strlen(sub);
    for (i=0; i<=n; i++)
        if (prefix(sub, text+i)) return 1;
    return 0;
}

int has_token(const char* text) {
    return substring("(", text) ||
           substring(")", text)        ||
           substring("goto", text)     ||
           substring("break", text)    ||
           substring("return", text)   ||
           substring("continue", text);
}
