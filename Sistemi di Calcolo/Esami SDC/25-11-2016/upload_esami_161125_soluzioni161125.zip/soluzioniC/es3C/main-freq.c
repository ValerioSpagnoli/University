#include <stdio.h>
#include "freq.h"

#define N 250000

char* text =
    "int prefix(const char* a, const char* b) {"
    "    int c = 0;"
    "    while (*a && *b) c += *a++ != *b++;"
    "    return !c && !*a;"
    "}"
    "int substring_count(const char* sub, const char* text) {"
    "   int c = 0;"
    "   for (i=0; i<strlen(text)-strlen(sub); i++)"
    "       if (prefix(sub+i, text+i)) c++;"
    "   return c;"
    "}";

int main() {
    int i, c = 0;

    for (i=0; i<N; i++) if (has_token(text)) c++;

    printf("%d (corretto=0)\n", has_token("this is a test"));
    printf("%d (corretto=1)\n", has_token("this is a (test)"));
    printf("%d (corretto=1)\n", has_token("gimme a break"));
    printf("%d (corretto=%d)\n", i, N);

    return 0;
}
