#include <string.h>
#include "freq.h"

// verifica se b inizia per a
static int prefix(const char* a, const char* b) {
    int c = 0;
    while (*a && *b) c += *a++ != *b++;
    return !c && !*a;
}

// conta quante volte sub è in text
static int substring_count(const char* sub, const char* text) {
    int i, c = 0, n = strlen(text)-strlen(sub);
    for (i=0; i<=n; i++)
        if (prefix(sub, text+i)) c++;
    return c;
}

int has_token(const char* text) {
    return substring_count("continue", text) ||
           substring_count("break", text)    ||
           substring_count("goto", text)     ||
           substring_count("return", text)   ||
           substring_count("(", text)        ||
           substring_count(")", text);
}
