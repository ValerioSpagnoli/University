#ifndef __FREQ__
#define __FREQ__

int has_token(const char* text);

#endif
