#include <stdio.h>

void arrayCrossMean(unsigned* x, unsigned* y, unsigned* z, unsigned n);

void printArray(unsigned* v, unsigned n) {
    printf("{");
    int i = 0;
    for (i=0; i<n-1; ++i)
        printf("%u, ", v[i]);
    printf("%u", v[i]);
    printf("}");
}

int main() {
    unsigned z[5];

    unsigned x1[4] = {1, 2, 0, 4};
    unsigned y1[4] = {2, 0, 3, 5};

    printf("Test 1:\nx: ");
    printArray(x1, 4);
    printf("\ny: ");
    printArray(y1, 4);
    arrayCrossMean(x1, y1, z, 4);
    printf("\nz: ");
    printArray(z, 4);
    printf("\nRisultato atteso:\nz: {3, 2, 0, 3}\n");

    unsigned x2[5] = {0, 7, 1, 0, 3};
    unsigned y2[5] = {2, 0, 1, 2, 1};

    printf("\nTest 2:\nx: ");
    printArray(x2, 5);
    printf("\ny: ");
    printArray(y2, 5);
    arrayCrossMean(x2, y2, z, 5);
    printf("\nz: ");
    printArray(z, 5);
    printf("\nRisultato atteso:\nz: {0, 4, 1, 0, 2}\n");

    return 0;
}
