void arrayCrossMean(unsigned* x, unsigned* y, unsigned* z, unsigned n) {
    unsigned* end = x+n;
    y = y+n-1;

    while (x < end) {
        *z = *x + *y;
        if (*z) *z = (*z) >> 1;
        x++, z++, y--;
    }
}
